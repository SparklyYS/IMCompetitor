#!/bin/bash

dataset=$1
echo -e "Start el2bin dataset: "${dataset}"\n"

#el2bin TR
echo -e "el2bin TR.......\n"
prob=(0.01 0.05 0.1 0.15 0.2)

for ((i=0; i<${#prob[@]}; i++))
do
	./gProcess/el2bin ./datasets/formats/TR/${dataset}_tr_${prob[$i]}".txt" ./datasets/formats/TR/${dataset}_tr_${prob[$i]}".bin"
done

echo -e "el2bin TR Over!"
echo -e "\n---------------------------\n"

#el2bin UN
echo -e "el2bin UN......\n"
prob=(0.01 0.05 0.1 0.15 0.2)

for ((i=0; i<${#prob[@]}; i++))
do
	./gProcess/el2bin ./datasets/formats/UN/${dataset}_un_${prob[$i]}".txt" ./datasets/formats/UN/${dataset}_un_${prob[$i]}".bin"
done

echo -e "el2bin TR Over!"
echo -e "\n---------------------------\n"

#el2bin WC
echo -e "el2bin WC.......\n"

./gProcess/el2bin ./datasets/formats/WC/${dataset}_wc".txt" ./datasets/formats/WC/${dataset}_wc".bin"

echo -e "el2bin WC Over!"
echo -e "\n---------------------------\n"

#el2bin Coarsen TR
echo -e "el2bin Coarsen TR.......\n"
prob=(0.01 0.05 0.1 0.15 0.2)

for ((i=0; i<${#prob[@]}; i++))
do
	./gProcess/el2bin ./datasets/coarsen/TR/${dataset}_tr_${prob[$i]}".txt_coarsened-graph.txt" ./datasets/coarsen/TR/${dataset}_tr_${prob[$i]}".txt_coarsened-graph.bin" 
done

echo -e "el2bin Coarsen TR Over!"
echo -e "\n---------------------------\n"

#el2bin Coarsen UN
echo -e "el2bin Coarsen UN.......\n"
prob=(0.01 0.05 0.1 0.15 0.2)

for ((i=0; i<${#prob[@]}; i++))
do
	./gProcess/el2bin ./datasets/coarsen/UN/${dataset}_un_${prob[$i]}".txt_coarsened-graph.txt" ./datasets/coarsen/UN/${dataset}_un_${prob[$i]}".txt_coarsened-graph.bin" 
done

echo -e "el2bin Coarsen UN Over!"
echo -e "\n---------------------------\n"

#el2bin Coarsen WC
echo -e "el2bin Coarsen WC......\n"

./gProcess/el2bin ./datasets/coarsen/WC/${dataset}_wc".txt_coarsened-graph.txt" ./datasets/coarsen/WC/${dataset}_wc".txt_coarsened-graph.bin"

echo -e "el2bin Coarsen WC Over!"
echo -e "\n---------------------------\n"

echo -e "Finish el2bin dataset: "${dataset}"\n"
