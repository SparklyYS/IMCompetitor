#!/bin/bash

# run Effect of K

datasets=("DBLP" "youtube" "LiveJournal")

for ((i=0; i<${#datasets[@]}; i++))
do
	./runKeffect.sh ${datasets[$i]}
done


