#!/bin/bash

graph_file=datasets/coarsen/hello.txt.bin

echo ${graph_file}
