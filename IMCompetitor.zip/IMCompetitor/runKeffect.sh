#!/bin/bash

#Effect of K
dataset=$1 #indicate the dataset
echo -e "Start run effect of K dataset: "${dataset}"\n"

#Arguments
K=(1 5 10 20 50 100 150 200)
eps=0.05

pT=0.1
pU=0.1

res_path=result/Keffect/${dataset}
mkdir ${res_path} # initial folder

mkdir ${res_path}/SKIS  # make SKIS folder
mkdir ${res_path}/Coarsen # make Coarsen folder
mkdir ${res_path}/DSSA # make DSSA folder

echo -e "Run TR Model.....\n"
#TR Model
logfile=${res_path}/${dataset}_tr_${pT}.log


#SKIS
graph_file=datasets/formats/TR/${dataset}_tr_${pT}.bin

echo -e "SKIS....\n"
echo -e "\n----------SKIS-----------\n" >> ${logfile}
for ((i=0; i<${#K[@]}; i++))
do
	echo -e "\n---------------------------\n" >> ${logfile}
	./algo/dssa_skis -i ${graph_file} -k ${K[$i]} -epsilon ${eps} -m IC -o ${res_path}/SKIS/[${dataset}_tr_${pT}][k=${K[$i]}][e=${eps}][SKIS].seeds >> ${logfile}   	
	echo -e "\n---------------------------\n" >> ${logfile}
done
echo -e "SKIS Over!\n"
echo -e "\n-----------SKIS Over----------\n" >> ${logfile}


#Coarsen

graph_file=datasets/coarsen/TR/${dataset}_tr_${pT}.txt_coarsened-graph.bin

echo -e "Coarsen....\n"
echo -e "\n----------Coarsen----------\n" >> ${logfile}
for ((i=0; i<${#K[@]}; i++))
do
	echo -e "\n---------------------------\n" >> ${logfile}
	./algo/dssa -i ${graph_file} -k ${K[$i]} -epsilon ${eps} -m IC -o ${res_path}/Coarsen/[${dataset}_tr_${pT}][k=${K[$i]}][e=${eps}][Coarsen].seeds >> ${logfile}
	echo -e "\n---------------------------\n" >> ${logfile}
done
echo -e "Coarsen Over!\n"
echo -e "\n----------Coarsen Over----------\n" >> ${logfile}

#DSSA
graph_file=datasets/formats/TR/${dataset}_tr_${pT}.bin

echo -e "DSSA....\n"
echo -e "\n----------DSSA----------\n" >> ${logfile}
for ((i=0; i<${#K[@]}; i++))
do
	echo -e "\n---------------------------\n" >> ${logfile}
	./algo/dssa -i ${graph_file} -k ${K[$i]} -epsilon ${eps} -m IC -o ${res_path}/DSSA/[${dataset}_tr_${pT}][k=${K[$i]}][e=${eps}][DSSA].seeds >> ${logfile}
	echo -e "\n---------------------------\n" >> ${logfile}
done
echo -e "DSSA Over!\n"
echo -e "\n----------DSSA Over----------\n" >> ${logfile}

echo -e "TR Model Over!\n\n"


echo -e "Run UN Model.....\n"
# UN Model
logfile=${res_path}/${dataset}_un_${pU}.log

#SKIS
graph_file=datasets/formats/UN/${dataset}_un_${pU}.bin

echo -e "SKIS.....\n"
echo -e "\n----------SKIS----------\n" >> ${logfile}
for ((i=0; i<${#K[@]}; i++))
do
	echo -e "\n---------------------------\n" >> ${logfile}
	./algo/dssa_skis -i ${graph_file} -k ${K[$i]} -epsilon ${eps} -m IC -o ${res_path}/SKIS/[${dataset}_un_${pU}][k=${K[$i]}][e=${eps}][SKIS].seeds >> ${logfile}   	
	echo -e "\n---------------------------\n" >> ${logfile}
done
echo -e "SKIS Over!\n"
echo -e "\n----------SKIS Over----------\n" >> ${logfile}

#Coarsen
graph_file=datasets/coarsen/UN/${dataset}_un_${pU}.txt_coarsened-graph.bin

echo -e "Coarsen.....\n"
echo -e "\n----------Coarsen----------\n" >> ${logfile}
for ((i=0; i<${#K[@]}; i++))
do
	echo -e "\n---------------------------\n" >> ${logfile}
	./algo/dssa -i ${graph_file} -k ${K[$i]} -epsilon ${eps} -m IC -o ${res_path}/Coarsen/[${dataset}_un_${pU}][k=${K[$i]}][e=${eps}][Coarsen].seeds >> ${logfile}
	echo -e "\n---------------------------\n" >> ${logfile}
done
echo -e "Coarsen Over!\n"
echo -e "\n----------Coarsen Over----------\n" >> ${logfile}


#DSSA
graph_file=datasets/formats/UN/${dataset}_un_${pU}.bin

echo -e "DSSA.....\n"
echo -e "\n----------DSSA----------\n" >> ${logfile}
for ((i=0; i<${#K[@]}; i++))
do
	echo -e "\n---------------------------\n" >> ${logfile}
	./algo/dssa -i ${graph_file} -k ${K[$i]} -epsilon ${eps} -m IC -o ${res_path}/DSSA/[${dataset}_un_${pU}][k=${K[$i]}][e=${eps}][DSSA].seeds >> ${logfile}
	echo -e "\n---------------------------\n" >> ${logfile}
done
echo -e "DSSA Over!\n"
echo -e "\n----------DSSA Over----------\n" >> ${logfile}

echo -e "UN Model Over!\n\n"

echo -e "Run WC Model......\n"
# WC Model
logfile=${res_path}/${dataset}_wc.log

#SKIS
graph_file=datasets/formats/WC/${dataset}_wc.bin

echo -e "SKIS.....\n"
echo -e "\n----------SKIS----------\n" >> ${logfile}
for ((i=0; i<${#K[@]}; i++))
do
	echo -e "\n---------------------------\n" >> ${logfile}
	./algo/dssa_skis -i ${graph_file} -k ${K[$i]} -epsilon ${eps} -m IC -o ${res_path}/SKIS/[${dataset}_wc][k=${K[$i]}][e=${eps}][SKIS].seeds >> ${logfile}   	
	echo -e "\n---------------------------\n" >> ${logfile}
done
echo -e "SKIS Over!\n"
echo -e "\n----------SKIS Over----------\n" >> ${logfile}

#Coarsen
graph_file=datasets/coarsen/WC/${dataset}_wc.txt_coarsened-graph.bin

echo -e "Coarsen.....\n"
echo -e "\n----------Coarsen----------\n" >> ${logfile}
for ((i=0; i<${#K[@]}; i++))
do
	echo -e "\n---------------------------\n" >> ${logfile}
	./algo/dssa -i ${graph_file} -k ${K[$i]} -epsilon ${eps} -m IC -o ${res_path}/Coarsen/[${dataset}_wc][k=${K[$i]}][e=${eps}][Coarsen].seeds >> ${logfile}
	echo -e "\n---------------------------\n" >> ${logfile}
done
echo -e "Coarsen Over!\n"
echo -e "\n----------Coarsen Over----------\n" >> ${logfile}

#DSSA
graph_file=datasets/formats/WC/${dataset}_wc.bin

echo -e "DSSA.....\n"
echo -e "\n----------DSSA----------\n" >> ${logfile}
for ((i=0; i<${#K[@]}; i++))
do
	echo -e "\n---------------------------\n" >> ${logfile}
	./algo/dssa -i ${graph_file} -k ${K[$i]} -epsilon ${eps} -m IC -o ${res_path}/DSSA/[${dataset}_wc][k=${K[$i]}][e=${eps}][DSSA].seeds >> ${logfile}
	echo -e "\n---------------------------\n" >> ${logfile}
done
echo -e "DSSA Over!\n"
echo -e "\n----------DSSA Over----------\n" >> ${logfile}

echo -e "WC Model Over!\n\n"
