#!/bin/bash

datasets=("Orkut" "Twitter" "friendster")

# Preprocessing Graph

for ((i=0; i<${#datasets[@]}; i++))
do
	./genSomeG.sh ${datasets[$i]}
	./coarseSomeG.sh ${datasets[$i]}
	./binSomeG.sh ${datasets[$i]}
done


