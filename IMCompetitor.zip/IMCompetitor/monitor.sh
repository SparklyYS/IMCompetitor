#!/bin/bash

#监控程序 监测运行时间超过1小时的进程 并kill

echo -e "Monitor\n\n"

while :
do
	ptime=`ps -ef | grep ./algo | grep -v grep | awk '{print $7}'`
	if [ ${ptime:0:2} == "01" ]
	then
		pid=`ps -ef | grep ./algo | grep -v grep | awk '{print $2}'`
		ps -ef | grep ./algo | grep -v grep | awk '{print $2}' | xargs kill
		echo "pid: ${pid} is killed"
	fi
	
	#每次监测间隔30s
	sleep 30
done
