#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>

using namespace std;

int main(int argc, char ** argv)
{
	ifstream in(argv[1]);
	ofstream out(argv[2]);

	unsigned long long n, m;
	unsigned long long u, v;
	in >> n >> m;
	
	out << n << " " << 2*m << endl;
	cout << n << " " << 2*m << endl;

	for (unsigned long long i = 0; i < m; i++)
	{
		in >> u >> v;
		out << u << " " << v << endl;
		out << v << " " << u << endl;
	}

	in.close();
	out.close();
	
	return 0;
}
