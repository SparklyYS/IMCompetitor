#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>

using namespace std;

int main(int argc, char ** argv)
{
	ifstream in(argv[1]);
	
	unsigned long long n, m;
	unsigned long long u, v;
	in >> n >> m;
	cout << n << " " << m << endl;
	
	for (int i = 0; i < m; i++)
	{
		in >> u >> v;
		if (u ==  v)
			cout << u << " " << v << endl;
		if (u >= n || v >= n)
			cout << u << " " << v << endl;
	}
	in.close();
	return 0;
}
