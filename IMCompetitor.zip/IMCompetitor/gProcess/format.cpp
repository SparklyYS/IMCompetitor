#include <vector>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include <iostream>

using namespace std;
const int MAXN = 66666666;

vector<unsigned long long> nodes[MAXN];
unsigned long long inDeg[MAXN];

int main(int argc, char ** argv)
{
	string in_file = string(argv[1]);
	string out_file = string(argv[2]);

	cout << in_file << endl;
	cout << out_file << endl;
	unsigned int flag = atoi(argv[3]); // 0: undirected | 1: directed
	unsigned int probM = atoi(argv[4]); // 0: wc | 1: tc | 2: un
	
	ifstream in(in_file.c_str());
	unsigned long long n, m;
	unsigned long long u, v;
	in >> n >> m;
	cout << "n = " << n << endl;
	cout << "m = " << m << endl;

	for (int i = 0; i < m; i++)
	{
		in >> u >> v;
		nodes[u].push_back(v);	
		inDeg[v]++;

		if (flag == 0)
		{
			nodes[v].push_back(u);
			inDeg[u]++;
		}
	}
	in.close();

	ofstream out(out_file.c_str());
	printf("Writing down to file!\n");
	out << n << " ";

	if (flag == 0)
		out << 2 * m << endl;
	else
		out << m << endl;

	if (probM == 0)
	{
		for (int i = 0; i < n; i++)
		{
			for (auto adjv : nodes[i])
			{
				double prob = 1.0 / inDeg[adjv];
				out << i << " " << adjv << " " << prob << endl;
			}
		}
	} // WC model
	else if (probM == 1) 
	{
		double pT = atof(argv[5]);
		
		// probability distribution
		double edge_prob[3] = {0};
		edge_prob[0] = pT;
		for (int i = 1; i < 3; i++)
			edge_prob[i] = edge_prob[i-1]*pT;

		srand(time(NULL));
		for (int i = 0; i < n; i++)
		{
			for (auto adjv : nodes[i])
			{
				int randn = rand() % 3;
				out << i << " " << adjv << " " << edge_prob[randn] << endl;
			}
		}
	} // TR model
	else
	{
		double pS = atof(argv[5]);

		for (int i = 0; i < n; i++)
		{
			for (auto adjv : nodes[i])
			{
				out << i << " " << adjv << " " << pS << endl;	
			}
		}
	}
	
	out.close();
	return 0;
}
