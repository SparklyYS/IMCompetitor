#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <algorithm>

using namespace std;
const int MAXN = 66666666;

vector<unsigned long long> nodes[MAXN];
unsigned long long inDeg[MAXN];

int main(int argc, char ** argv)
{
	ifstream in(argv[1]);
	ofstream out(argv[2]);
	int flag = atoi(argv[3]); // 0 tr | 1 un | 2 wc	
	
	double p = 0.1;
	if (flag == 0 || flag == 1)
		p = atof(argv[4]);

	unsigned long long n, m;
	unsigned long long u, v;
	in >> n >> m;
	
	out << n << " " << m << endl;

	srand((unsigned) time(NULL));
	if (flag == 0)
	{
		double d[] = {p, p*p, p*p*p};

		for (int i = 0; i < m; i++)
		{
			in >> u >> v;
			int randn = rand() % 3;
			out << u << " " << v << " " << d[randn] << endl;
		}
	} // tr model
	else if (flag == 1)
	{
		for (int i = 0; i < m; i++)
		{
			in >> u >> v;
			out << u << " " << v << " " << p << endl;
		}
	}
	else
	{
		for (int i = 0; i < m; i++)
		{
			in >> u >> v;
			nodes[u].push_back(v);
			inDeg[v]++;
		}

		for (unsigned long long i = 0; i < n; i++)
		{
			for (auto adjv : nodes[i])
			{
				double prob = 1.0 / inDeg[adjv];
				out << i << " " << adjv << " " << prob << endl;
			}
		}
	}

	in.close();
	out.close();

	return 0;
}
