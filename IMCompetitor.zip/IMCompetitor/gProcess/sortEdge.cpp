#include <vector>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>
#include <algorithm>

using namespace std;

struct Edge
{
	unsigned long long u, v;
	
	Edge(unsigned long long _u, unsigned long long _v): u(_u), v(_v) {}
};

bool comp(const Edge &e1, const Edge &e2)
{
	if (e1.u == e2.u)
		return e1.v < e2.v;
	return e1.u < e2.u;
}

vector<Edge> edges;

int main(int argc, char ** argv)
{
	ifstream in(argv[1]);
	ofstream out(argv[2]);

	unsigned long long n, m;
	unsigned long long u, v;

	in >> n >> m;
	for (int i = 0; i < m; i++)
	{
		in >> u >> v;
		edges.push_back(Edge(u, v));
	}

	sort(edges.begin(), edges.end(), comp);
	
	out << n << " " << m << endl;
	for (int i = 0; i < m; i++)
		out << edges[i].u << " " << edges[i].v << endl;

	in.close();
	out.close();

	return 0;
}
