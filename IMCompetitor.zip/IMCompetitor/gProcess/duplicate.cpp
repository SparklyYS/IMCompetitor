#include <vector>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <algorithm>

using namespace std;
const int MAXN = 6660000;

vector<unsigned long long> nodes[MAXN];

int main(int argc, char ** argv)
{
	ifstream in(argv[1]);
	ofstream out(argv[2]);

	unsigned long long n, m, rm = 1;
	unsigned long long p1, p2, u, v;

	in >> n >> m;

	in >> p1 >> p2;
	nodes[p1].push_back(p2);

	for (int i = 1; i < m; i++)
	{
		in >> u >> v;
		if (u == v)
			continue;
		if (u == p1 && v == p2)
			continue;

		nodes[u].push_back(v);
		p1 = u;
		p2 = v;
		rm++;
	}

	out << n << " " << rm << endl;
	for (unsigned long long i = 0; i < n; i++)
	{
		for (auto adjv : nodes[i])
		{
			out << i << " " << adjv << endl;
		}

	}

	in.close();
	out.close();	
	
	return 0;
}
