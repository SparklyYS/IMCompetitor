#include <map>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>

using namespace std;

map<unsigned long long, unsigned long long> mp;
int main(int argc, char ** argv)
{
	ifstream in(argv[1]);
	ofstream out(argv[2]);

	unsigned long long n, m;
	unsigned long long u, v;

	in >> n >> m;
	out << n << " " << m << endl;

	unsigned long long idx = 0;
	for (int i = 0; i < m; i++)
	{
		in >> u >> v;
		if (mp.count(u) == 0)
			mp[u] = idx++;
		if (mp.count(v) == 0)
			mp[v] = idx++;
		
		out << mp[u] << " " << mp[v] << endl;
	}			
	
	in.close();
	out.close();

	return 0;
}
