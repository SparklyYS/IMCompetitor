#!/bin/bash

dataset=$1
echo -e "Start coarsen dataset: "${dataset}"\n"

#coarsen TR
echo -e "Coarsen TR......\n"
prob=(0.01 0.05 0.1 0.15 0.2)

logfile=result/coarsen/${dataset}_tr.log
for ((i=0; i<${#prob[@]}; i++))
do
	echo -e "\n--------------------------------------\n" >> ${logfile}
	./algo/coarsen ./datasets/formats/TR/${dataset}_tr_${prob[$i]}".txt" 16 ./datasets/coarsen/TR/${dataset}_tr_${prob[$i]}".txt" 1 >> ${logfile}
	echo -e "\n--------------------------------------\n" >> ${logfile} 
done

echo -e "Coarsen TR Over!\n\n"

#coarsen UN
echo -e "Coarsen UN......\n"
prob=(0.01 0.05 0.1 0.15 0.2)

logfile=result/coarsen/${dataset}_un.log
for ((i=0; i<${#prob[@]}; i++))
do
	echo -e "\n--------------------------------------\n" >> ${logfile} 	
	./algo/coarsen ./datasets/formats/UN/${dataset}_un_${prob[$i]}".txt" 16 ./datasets/coarsen/UN/${dataset}_un_${prob[$i]}".txt" 1 >> ${logfile}
	echo -e "\n--------------------------------------\n" >> ${logfile}	
done

echo -e "Coarsen UN Over!\n\n"

#coarsen WC
echo -e "Coarsen WC......\n"

logfile=result/coarsen/${dataset}_wc.log
./algo/coarsen ./datasets/formats/WC/${dataset}_wc".txt" 16 ./datasets/coarsen/WC/${dataset}_wc".txt" 1 >> ${logfile}

echo -e "Coarsen WC Over!\n\n"

echo -e "Finish coarsen dataset: "${dataset}"\n"

