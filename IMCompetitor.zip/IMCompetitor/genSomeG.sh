#!/bin/bash

dataset=$1 # Indicate the dataset
echo -e "Start generate probability in dataset: "${dataset}"\n"

#gen TR
echo -e "gen TR.......\n"
prob=(0.01 0.05 0.1 0.15 0.2)

for ((i=0; i<${#prob[@]}; i++))
do
	./gProcess/genProb ./datasets/output/${dataset}".txt" ./datasets/formats/TR/${dataset}_tr_${prob[$i]}".txt" 0 ${prob[$i]}
done

echo -e "gen TR Over!"
echo -e "\n---------------------------\n"

#gen UN
echo -e "gen UN......\n"
prob=(0.01 0.05 0.1 0.15 0.2)

for ((i=0; i<${#prob[@]}; i++))
do
	./gProcess/genProb ./datasets/output/${dataset}".txt" ./datasets/formats/UN/${dataset}_un_${prob[$i]}".txt" 1 ${prob[$i]}
done

echo -e "gen UN Over!"
echo -e "\n---------------------------\n"

#gen WC
echo -e "gen WC......\n"

./gProcess/genProb ./datasets/output/${dataset}".txt" ./datasets/formats/WC/${dataset}_wc".txt" 2

echo -e "gen WC Over!"
echo -e "\n---------------------------\n"

echo -e "Finish generate probability in dataset: "${dataset}"\n"


