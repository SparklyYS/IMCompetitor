#!/bin/bash

dataset=$1 # Indicate the dataset
echo -e "Start to estimate the influence score in dataset: " ${dataset}"\n"

#Aruguments
K=(1 5 10 20 50 100 150 200)
eps=0.5

pT=0.1
pU=0.1

R=200

res_path=result/Keffect/${dataset}

#TR Model
echo -e "Estiamte TR Model......\n"

logfile=${res_path}/${dataset}_tr_${pT}_estimate.log
graph_file=datasets/formats/TR/${dataset}_tr_${pT}.txt

#SKIS

echo -e "SKIS....\n"
echo -e "\n----------SKIS----------\n" >> ${logfile}
for ((i=0; i<${#K[@]}; i++))
do
	seedFile=${res_path}/SKIS/[${dataset}_tr_${pT}][k=${K[$i]}][e=${eps}][SKIS].seeds
	./algo/mctest -i ${graph_file} -s ${seedFile} -r ${R} >> ${logfile}
done
echo -e "SKIS Over!\n"
echo -e "\n----------SKIS Over-----------\n" >> ${logfile}


#Coarsen

mapFile=datasets/coarsen/TR/

echo -e "Coarsen....\n"
echo -e "\n----------Coarsen----------\n" >> ${logfile}
for ((i=0; i<${#K[@]}; i++))
do
	seedFile=${res_path}/SKIS/[${dataset}]
done








